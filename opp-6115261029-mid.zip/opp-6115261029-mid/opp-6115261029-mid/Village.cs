﻿using System;
using System.Collections.Generic;
using System.Text;

namespace opp_6115261029_mid
{
    class Village
    {
        private string name;
        private int cost;
        public string Name { get => name; set => name = value; }
        public int val { get => val; set => val = value; }
        public Village()
        {
        }
        public Village (string name, int val)
        {
            this.name = name;
            this.val = val;
        }
        public override string ToString()
        {
            return this.Name + " " +
                this.val;
        }
    }
}
